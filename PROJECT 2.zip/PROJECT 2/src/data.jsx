export default [
  {
    id: 1,
    title: "Thekkady",
    location: "Kerala, India",
    googleMapsUrl:
      "https://www.google.com/maps/place/Thekkady,+Kumily,+Kerala/@9.6093965,77.1429913,14z/data=!3m1!4b1!4m5!3m4!1s0x3b06f8812df2a199:0x468af17958c54ae8!8m2!3d9.6031088!4d77.161458",
    startDate: "23 DEC 2022",
    endDate: "25 DEC 2022",
    description:
      "Thekkady is a place located in the high ranges of Kerala. It is one of the most popular hill stations. Periyar Forest in Thekkady is one of the most famous wildlife sanctuary",
    imageUrl: "img1.JPG",
  },
  {
    id: 2,
    title: "Kumarakom",
    location: "Kerala, India",
    googleMapsUrl:
      "https://www.google.com/maps/place/Kumarakom,+Kerala/@9.610511,76.3689248,12z/data=!3m1!4b1!4m5!3m4!1s0x3b0881caaef0a8f7:0xc23075c3529e921!8m2!3d9.6175449!4d76.430095",
    startDate: "26 DEC 2022",
    endDate: "26 DEC 2022",
    description:
      "Kumarakom is very famous for its bird sanctuary. A wide variety of birds can be seen during the months from March to July.",
    imageUrl: "img2.JPG",
  },
];
