import React from "react";
import ReactDOM from "react-dom";
import "./Card.css";
import locLogo from "../assets/Fill 219.png";
import img from "../images/img1.jpg";
export default function Card(props) {
  return (
    <div className="card-box">
      <img
        src={`/src/images/${props.item.imageUrl}`}
        alt="place photo"
        className="card-img"
      />
      <div className="card-content">
        <div className="loc-box">
          <img src={locLogo} alt="locLogo" className="loc-logo" />
          <h6 className="country-name">{props.item.location}</h6>
          <a
            href={props.item.googleMapsUrl}
            className="loc-link"
            target="_blank"
          >
            View on Google Maps
          </a>
        </div>
        <h1 className="loc-name">{props.item.title}</h1>
        <h3 className="start-end">
          {props.item.startDate} to {props.item.endDate}
        </h3>
        <p className="desc">{props.item.description}</p>
      </div>
    </div>
  );
}
