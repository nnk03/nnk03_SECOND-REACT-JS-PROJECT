import React from "react";
import ReactDOM from "react-dom";
import "./Navbar.css";
import world from "../assets/Fill 213.png";
// import world from "../assets/Fill 213.png";

export default function Navbar() {
  return (
    <nav className="navbar">
      <div className="heading">
        <img src={world} alt="world logo" />
        <h3>my Travel Journal</h3>
      </div>
    </nav>
  );
}
